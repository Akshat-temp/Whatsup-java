package main;

import models.user;
import models.post;
import algorithm.usertrie;
import algorithm.socialgraph;
import algorithm.feedranker;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;

public class Main {

    static Map<String, user> userStore = new HashMap<>();
    static Map<String, post> postStore = new HashMap<>();
    static int postCounter = 1;

    static usertrie trie = new usertrie();
    static socialgraph graph = new socialgraph();
    static feedranker ranker = new feedranker();
    static user currentUser = null;

    static user viewingUser = null;

    static Color ACCENT = new Color(131, 58, 180);
    static Color DARK = new Color(30, 30, 30);
    static Color GREY = new Color(200, 200, 200);
    static Color WHITE = Color.WHITE;

    static JFrame frame = new JFrame("InstaClone");
    static CardLayout cards = new CardLayout();
    static JPanel root = new JPanel(cards);

    static JLabel homeGreeting = new JLabel("", SwingConstants.CENTER);
    static JLabel profName = new JLabel("", SwingConstants.CENTER);
    static JPanel profStats = new JPanel();
    static JPanel profPostsPanel = new JPanel();
    static JPanel profActionPanel = new JPanel();
    static JTextField searchBox = new JTextField();
    static JPanel searchResults = new JPanel();
    static JPanel feedPostsPanel = new JPanel();
    static JPanel recommendPanel = new JPanel();

    public static void main(String[] args) {
        frame.setSize(420, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        root.add(welcomeScreen(), "WELCOME");
        root.add(signupScreen(), "SIGNUP");
        root.add(loginScreen(), "LOGIN");
        root.add(homeScreen(), "HOME");
        root.add(profileScreen(), "PROFILE");
        root.add(searchScreen(), "SEARCH");
        root.add(feedScreen(), "FEED");
        root.add(uploadScreen(), "UPLOAD");
        root.add(recommendScreen(), "RECOMMEND");
        frame.add(root);
        cards.show(root, "WELCOME");
        frame.setVisible(true);
    }

    static JPanel welcomeScreen() {
        JPanel p = centeredPanel();
        JLabel logo = new JLabel("InstaClone");
        logo.setFont(new Font("Georgia", Font.ITALIC, 36));
        logo.setForeground(ACCENT);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel sub = new JLabel("Share your moments.");
        sub.setFont(new Font("Arial", Font.PLAIN, 13));
        sub.setForeground(Color.GRAY);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);
        JButton s = bigButton("Sign Up", ACCENT, WHITE);
        JButton l = outlineButton("Log In");
        s.addActionListener(e -> cards.show(root, "SIGNUP"));
        l.addActionListener(e -> cards.show(root, "LOGIN"));
        p.add(logo);
        p.add(gap(6));
        p.add(sub);
        p.add(gap(40));
        p.add(s);
        p.add(gap(10));
        p.add(l);
        return p;
    }

    static JPanel signupScreen() {
        JPanel p = centeredPanel();
        JTextField uF = styledField("Username");
        JPasswordField pF = new JPasswordField();
        stylePlaceholder(pF, "Password");
        JLabel msg = msgLabel();
        JButton btn = bigButton("Sign Up", ACCENT, WHITE);
        JButton back = linkButton("← Back");
        btn.addActionListener(e -> {
            String u = uF.getText().trim(), pw = new String(pF.getPassword()).trim();
            if (u.isEmpty() || pw.isEmpty()) {
                msg.setText("Fill in all fields.");
                return;
            }
            if (userStore.containsKey(u)) {
                msg.setText("Username already taken.");
                return;
            }
            if (pw.length() < 4) {
                msg.setText("Password min 4 characters.");
                return;
            }
            userStore.put(u, new user(u, pw));
            trie.insert(u);
            graph.addUser(u);
            msg.setForeground(new Color(0, 150, 0));
            msg.setText("Account created! Please log in.");
            uF.setText("");
            pF.setText("");
        });
        back.addActionListener(e -> {
            msg.setText("");
            cards.show(root, "WELCOME");
        });
        p.add(screenTitle("Create Account"));
        p.add(gap(20));
        p.add(uF);
        p.add(gap(10));
        p.add(pF);
        p.add(gap(20));
        p.add(btn);
        p.add(gap(8));
        p.add(msg);
        p.add(gap(10));
        p.add(back);
        return p;
    }

    static JPanel loginScreen() {
        JPanel p = centeredPanel();
        JTextField uF = styledField("Username");
        JPasswordField pF = new JPasswordField();
        stylePlaceholder(pF, "Password");
        JLabel msg = msgLabel();
        JButton btn = bigButton("Log In", ACCENT, WHITE);
        JButton back = linkButton("← Back");
        btn.addActionListener(e -> {
            String u = uF.getText().trim(), pw = new String(pF.getPassword()).trim();
            user found = userStore.get(u);
            if (found == null || !found.getPassword().equals(pw)) {
                msg.setText("Wrong username or password.");
                return;
            }
            currentUser = found;
            uF.setText("");
            pF.setText("");
            msg.setText("");
            homeGreeting.setText("Welcome, " + currentUser.getUsername() + "!");
            cards.show(root, "HOME");
        });
        back.addActionListener(e -> {
            msg.setText("");
            cards.show(root, "WELCOME");
        });
        p.add(screenTitle("Log In"));
        p.add(gap(20));
        p.add(uF);
        p.add(gap(10));
        p.add(pF);
        p.add(gap(20));
        p.add(btn);
        p.add(gap(8));
        p.add(msg);
        p.add(gap(10));
        p.add(back);
        return p;
    }

    static JPanel homeScreen() {
        JPanel p = centeredPanel();
        homeGreeting.setFont(new Font("Arial", Font.BOLD, 16));
        homeGreeting.setForeground(DARK);
        homeGreeting.setAlignmentX(Component.CENTER_ALIGNMENT);
        JButton pb = bigButton("Profile", ACCENT, WHITE);
        JButton sb = bigButton("Search", new Color(60, 60, 60), WHITE);
        JButton fb = bigButton("Feed", new Color(60, 60, 60), WHITE);
        JButton rb = bigButton("People You May Know", new Color(60, 60, 60), WHITE);
        JButton lb = linkButton("Log Out");
        pb.addActionListener(e -> {
            viewingUser = currentUser;
            refreshProfile();
            cards.show(root, "PROFILE");
        });
        sb.addActionListener(e -> {
            searchBox.setText("");
            searchResults.removeAll();
            searchResults.revalidate();
            searchResults.repaint();
            cards.show(root, "SEARCH");
        });
        fb.addActionListener(e -> {
            refreshFeed();
            cards.show(root, "FEED");
        });
        rb.addActionListener(e -> {
            refreshRecommend();
            cards.show(root, "RECOMMEND");
        });
        lb.addActionListener(e -> {
            currentUser = null;
            cards.show(root, "WELCOME");
        });
        p.add(homeGreeting);
        p.add(gap(30));
        p.add(pb);
        p.add(gap(10));
        p.add(sb);
        p.add(gap(10));
        p.add(fb);
        p.add(gap(10));
        p.add(rb);
        p.add(gap(30));
        p.add(lb);
        return p;
    }

    static JPanel profileScreen() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(WHITE);

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(WHITE);
        topBar.setBorder(new MatteBorder(0, 0, 1, 0, GREY));
        profName.setFont(new Font("Arial", Font.BOLD, 16));
        profName.setBorder(BorderFactory.createEmptyBorder(12, 0, 12, 0));
        JButton back = linkButton("←");
        back.addActionListener(e -> {

            cards.show(root, "HOME");
        });
        topBar.add(back, BorderLayout.WEST);
        topBar.add(profName, BorderLayout.CENTER);

        profStats.setBackground(WHITE);
        profStats.setLayout(new GridLayout(1, 3));
        profStats.setBorder(BorderFactory.createEmptyBorder(16, 10, 16, 10));

        profActionPanel.setBackground(WHITE);
        profActionPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 4));

        profPostsPanel.setLayout(new BoxLayout(profPostsPanel, BoxLayout.Y_AXIS));
        profPostsPanel.setBackground(WHITE);

        JPanel mid = new JPanel(new BorderLayout());
        mid.setBackground(WHITE);
        mid.add(profStats, BorderLayout.NORTH);
        mid.add(profActionPanel, BorderLayout.CENTER);
        mid.add(new JScrollPane(profPostsPanel), BorderLayout.SOUTH);

        JPanel bodyWrapper = new JPanel(new BorderLayout());
        bodyWrapper.setBackground(WHITE);
        bodyWrapper.add(profStats, BorderLayout.NORTH);

        JPanel midSection = new JPanel(new BorderLayout());
        midSection.setBackground(WHITE);
        midSection.add(profActionPanel, BorderLayout.NORTH);
        midSection.add(new JScrollPane(profPostsPanel), BorderLayout.CENTER);

        bodyWrapper.add(midSection, BorderLayout.CENTER);
        p.add(topBar, BorderLayout.NORTH);
        p.add(bodyWrapper, BorderLayout.CENTER);
        return p;
    }

    static void refreshProfile() {
        if (viewingUser == null)
            viewingUser = currentUser;

        profName.setText(viewingUser.getUsername());

        profStats.removeAll();
        profStats.add(statBox(String.valueOf(viewingUser.getPostCount()), "Posts"));
        profStats.add(statBox(String.valueOf(viewingUser.getFollowerCount()), "Followers"));
        profStats.add(statBox(String.valueOf(viewingUser.getFollowingCount()), "Following"));
        profStats.revalidate();
        profStats.repaint();

        profActionPanel.removeAll();
        boolean isOwn = viewingUser.getUsername().equals(currentUser.getUsername());
        if (isOwn) {
            JButton uploadBtn = new JButton("+ Upload Post");
            uploadBtn.setFont(new Font("Arial", Font.BOLD, 13));
            uploadBtn.setBackground(ACCENT);
            uploadBtn.setForeground(WHITE);
            uploadBtn.setFocusPainted(false);
            uploadBtn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
            uploadBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            uploadBtn.addActionListener(e -> cards.show(root, "UPLOAD"));
            profActionPanel.add(uploadBtn);
        } else {
            boolean alreadyFollowing = currentUser.getFollowing().contains(viewingUser.getUsername());
            JButton followBtn = new JButton(alreadyFollowing ? "Unfollow" : "Follow");
            followBtn.setFont(new Font("Arial", Font.BOLD, 13));
            followBtn.setBackground(alreadyFollowing ? GREY : ACCENT);
            followBtn.setForeground(alreadyFollowing ? DARK : WHITE);
            followBtn.setFocusPainted(false);
            followBtn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
            followBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            followBtn.addActionListener(e -> {
                String from = currentUser.getUsername();
                String to = viewingUser.getUsername();
                if (!alreadyFollowing) {
                    graph.follow(from, to);
                    currentUser.addFollowing(to);
                    viewingUser.addFollower(from);
                } else {
                    graph.unfollow(from, to);
                    currentUser.removeFollowing(to);
                    viewingUser.removeFollower(from);
                }
                refreshProfile();
            });
            profActionPanel.add(followBtn);
        }
        profActionPanel.revalidate();
        profActionPanel.repaint();

        profPostsPanel.removeAll();
        List<String> ids = viewingUser.getPostIds();
        if (ids.isEmpty()) {
            JLabel none = new JLabel("No posts yet.", SwingConstants.CENTER);
            none.setForeground(Color.GRAY);
            none.setAlignmentX(Component.CENTER_ALIGNMENT);
            profPostsPanel.add(gap(20));
            profPostsPanel.add(none);
        } else {
            for (String pid : ids) {
                post po = postStore.get(pid);
                if (po == null)
                    continue;
                JPanel card = new JPanel(new BorderLayout());
                card.setBackground(WHITE);
                card.setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, GREY),
                        BorderFactory.createEmptyBorder(8, 12, 8, 12)));
                JLabel info = new JLabel("[" + pid + "]  " + po.getLikes() + " likes");
                info.setForeground(DARK);
                JLabel url = new JLabel(po.getImageUrl());
                url.setForeground(Color.GRAY);
                url.setFont(new Font("Arial", Font.PLAIN, 10));
                card.add(info, BorderLayout.NORTH);
                card.add(url, BorderLayout.CENTER);
                profPostsPanel.add(card);
            }
        }
        profPostsPanel.revalidate();
        profPostsPanel.repaint();
    }

    static JPanel searchScreen() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(WHITE);
        JPanel topBar = new JPanel(new BorderLayout(6, 0));
        topBar.setBackground(WHITE);
        topBar.setBorder(
                new CompoundBorder(new MatteBorder(0, 0, 1, 0, GREY), BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        searchBox.setFont(new Font("Arial", Font.PLAIN, 14));
        searchBox.setBorder(
                new CompoundBorder(BorderFactory.createLineBorder(GREY), BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        JButton back = linkButton("←");
        back.addActionListener(e -> {
            searchBox.setText("");
            cards.show(root, "HOME");
        });
        topBar.add(back, BorderLayout.WEST);
        topBar.add(searchBox, BorderLayout.CENTER);
        searchBox.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                doSearch();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                doSearch();
            }

            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                doSearch();
            }
        });
        searchResults.setLayout(new BoxLayout(searchResults, BoxLayout.Y_AXIS));
        searchResults.setBackground(WHITE);
        p.add(topBar, BorderLayout.NORTH);
        p.add(new JScrollPane(searchResults), BorderLayout.CENTER);
        return p;
    }

    static void doSearch() {
        String prefix = searchBox.getText().trim();
        searchResults.removeAll();
        if (!prefix.isEmpty()) {
            for (String name : trie.searchByPrefix(prefix)) {
                JPanel row = new JPanel(new BorderLayout());
                row.setBackground(WHITE);
                row.setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, GREY),
                        BorderFactory.createEmptyBorder(10, 14, 10, 14)));
                row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
                JLabel lbl = new JLabel(name);
                lbl.setFont(new Font("Arial", Font.PLAIN, 14));
                row.add(lbl, BorderLayout.CENTER);
                row.setCursor(new Cursor(Cursor.HAND_CURSOR));
                row.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseClicked(java.awt.event.MouseEvent e) {
                        viewingUser = userStore.get(name);
                        refreshProfile();
                        cards.show(root, "PROFILE");
                    }
                });
                searchResults.add(row);
            }
        }
        searchResults.revalidate();
        searchResults.repaint();
    }

    static JPanel feedScreen() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(WHITE);
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(WHITE);
        topBar.setBorder(
                new CompoundBorder(new MatteBorder(0, 0, 1, 0, GREY), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        JLabel title = new JLabel("Feed", SwingConstants.CENTER);
        title.setFont(new Font("Georgia", Font.ITALIC, 18));
        title.setForeground(ACCENT);
        JButton back = linkButton("←");
        back.addActionListener(e -> cards.show(root, "HOME"));
        topBar.add(back, BorderLayout.WEST);
        topBar.add(title, BorderLayout.CENTER);
        feedPostsPanel.setLayout(new BoxLayout(feedPostsPanel, BoxLayout.Y_AXIS));
        feedPostsPanel.setBackground(WHITE);
        p.add(topBar, BorderLayout.NORTH);
        p.add(new JScrollPane(feedPostsPanel), BorderLayout.CENTER);
        return p;
    }

    static void refreshFeed() {
        feedPostsPanel.removeAll();
        List<post> feed = ranker.getRankedFeed(new ArrayList<>(postStore.values()));
        if (feed.isEmpty()) {
            JLabel none = new JLabel("No posts yet.", SwingConstants.CENTER);
            none.setForeground(Color.GRAY);
            none.setFont(new Font("Arial", Font.PLAIN, 14));
            none.setAlignmentX(Component.CENTER_ALIGNMENT);
            feedPostsPanel.add(gap(40));
            feedPostsPanel.add(none);
        } else {
            for (post po : feed)
                feedPostsPanel.add(feedCard(po));
        }
        feedPostsPanel.revalidate();
        feedPostsPanel.repaint();
    }

    static JPanel feedCard(post po) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(WHITE);
        card.setBorder(
                new CompoundBorder(new MatteBorder(0, 0, 1, 0, GREY), BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        JLabel author = new JLabel(po.getAuthorUsername());
        author.setFont(new Font("Arial", Font.BOLD, 13));
        JLabel imgLabel = new JLabel("Loading...", SwingConstants.CENTER);
        imgLabel.setPreferredSize(new Dimension(380, 300));
        imgLabel.setBackground(new Color(240, 240, 240));
        imgLabel.setOpaque(true);
        new Thread(() -> {
            try {
                BufferedImage img = ImageIO.read(new File(po.getImageUrl()));
                if (img != null) {
                    Image scaled = img.getScaledInstance(380, 300, Image.SCALE_SMOOTH);
                    SwingUtilities.invokeLater(() -> {
                        imgLabel.setIcon(new ImageIcon(scaled));
                        imgLabel.setText("");
                    });
                } else {
                    SwingUtilities.invokeLater(() -> imgLabel.setText("Could not load image."));
                }
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> imgLabel.setText("Could not load image."));
            }
        }).start();
        JLabel likesLabel = new JLabel(po.getLikes() + " likes");
        likesLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        JButton likeBtn = new JButton("♡ Like");
        likeBtn.setBackground(WHITE);
        likeBtn.setForeground(ACCENT);
        likeBtn.setBorder(BorderFactory.createLineBorder(ACCENT));
        likeBtn.setFocusPainted(false);
        likeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        likeBtn.addActionListener(e -> {
            po.like();
            likesLabel.setText(po.getLikes() + " likes");
        });
        JPanel likeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 4));
        likeRow.setBackground(WHITE);
        likeRow.add(likeBtn);
        likeRow.add(Box.createHorizontalStrut(10));
        likeRow.add(likesLabel);
        card.add(author, BorderLayout.NORTH);
        card.add(imgLabel, BorderLayout.CENTER);
        card.add(likeRow, BorderLayout.SOUTH);
        return card;
    }

    static JPanel uploadScreen() {
        JPanel p = centeredPanel();
        JLabel selected = new JLabel("No file selected.");
        selected.setForeground(Color.GRAY);
        selected.setFont(new Font("Arial", Font.PLAIN, 12));
        selected.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel msg = msgLabel();
        JButton browse = bigButton("Browse Image", new Color(60, 60, 60), WHITE);
        JButton upload = bigButton("Upload", ACCENT, WHITE);
        JButton back = linkButton("← Back");
        final String[] chosenPath = { "" };
        browse.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select an Image");
            chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                    "Image files", "jpg", "jpeg", "png", "gif", "bmp"));
            if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
                chosenPath[0] = chooser.getSelectedFile().getAbsolutePath();
                selected.setText(chooser.getSelectedFile().getName());
                selected.setForeground(DARK);
            }
        });
        upload.addActionListener(e -> {
            if (chosenPath[0].isEmpty()) {
                msg.setText("Please select an image first.");
                return;
            }
            String postId = "P" + postCounter++;
            post po = new post(postId, currentUser.getUsername(), chosenPath[0]);
            postStore.put(postId, po);
            currentUser.addPostId(postId);
            msg.setForeground(new Color(0, 150, 0));
            msg.setText("Uploaded! ID: " + postId);
            selected.setText("No file selected.");
            selected.setForeground(Color.GRAY);
            chosenPath[0] = "";
        });
        back.addActionListener(e -> {
            msg.setText("");
            viewingUser = currentUser;
            refreshProfile();
            cards.show(root, "PROFILE");
        });
        p.add(screenTitle("Upload Post"));
        p.add(gap(20));
        p.add(browse);
        p.add(gap(12));
        p.add(selected);
        p.add(gap(20));
        p.add(upload);
        p.add(gap(8));
        p.add(msg);
        p.add(gap(10));
        p.add(back);
        return p;
    }

    static JPanel recommendScreen() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(WHITE);
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(WHITE);
        topBar.setBorder(
                new CompoundBorder(new MatteBorder(0, 0, 1, 0, GREY), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        JLabel title = new JLabel("People You May Know", SwingConstants.CENTER);
        title.setFont(new Font("Georgia", Font.ITALIC, 18));
        title.setForeground(ACCENT);
        JButton back = linkButton("←");
        back.addActionListener(e -> cards.show(root, "HOME"));
        topBar.add(back, BorderLayout.WEST);
        topBar.add(title, BorderLayout.CENTER);
        recommendPanel.setLayout(new BoxLayout(recommendPanel, BoxLayout.Y_AXIS));
        recommendPanel.setBackground(WHITE);
        p.add(topBar, BorderLayout.NORTH);
        p.add(new JScrollPane(recommendPanel), BorderLayout.CENTER);
        return p;
    }

    static void refreshRecommend() {
        recommendPanel.removeAll();
        List<String> suggestions = graph.recommendUsers(currentUser.getUsername());
        if (suggestions.isEmpty()) {
            JLabel none = new JLabel("No suggestions yet. Follow more people first.", SwingConstants.CENTER);
            none.setForeground(Color.GRAY);
            none.setFont(new Font("Arial", Font.PLAIN, 13));
            none.setAlignmentX(Component.CENTER_ALIGNMENT);
            recommendPanel.add(gap(40));
            recommendPanel.add(none);
        } else {
            for (String name : suggestions) {
                JPanel row = new JPanel(new BorderLayout(10, 0));
                row.setBackground(WHITE);
                row.setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, GREY),
                        BorderFactory.createEmptyBorder(10, 14, 10, 14)));
                row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
                JLabel lbl = new JLabel(name);
                lbl.setFont(new Font("Arial", Font.PLAIN, 14));
                JButton followBtn = new JButton("Follow");
                followBtn.setFont(new Font("Arial", Font.BOLD, 12));
                followBtn.setBackground(ACCENT);
                followBtn.setForeground(WHITE);
                followBtn.setFocusPainted(false);
                followBtn.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
                followBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
                followBtn.addActionListener(e -> {
                    user toUser = userStore.get(name);
                    if (toUser != null && !currentUser.getFollowing().contains(name)) {
                        graph.follow(currentUser.getUsername(), name);
                        currentUser.addFollowing(name);
                        toUser.addFollower(currentUser.getUsername());
                        followBtn.setText("Following");
                        followBtn.setBackground(GREY);
                        followBtn.setForeground(DARK);
                    }
                });

                if (currentUser.getFollowing().contains(name)) {
                    followBtn.setText("Following");
                    followBtn.setBackground(GREY);
                    followBtn.setForeground(DARK);
                }
                row.add(lbl, BorderLayout.CENTER);
                row.add(followBtn, BorderLayout.EAST);
                recommendPanel.add(row);
            }
        }
        recommendPanel.revalidate();
        recommendPanel.repaint();
    }

    static JPanel centeredPanel() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(60, 50, 60, 50));
        return p;
    }

    static JLabel screenTitle(String text) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setFont(new Font("Georgia", Font.ITALIC, 22));
        l.setForeground(ACCENT);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        return l;
    }

    static JTextField styledField(String ph) {
        JTextField f = new JTextField();
        f.setFont(new Font("Arial", Font.PLAIN, 14));
        f.setBorder(new CompoundBorder(BorderFactory.createLineBorder(GREY),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        f.setForeground(Color.GRAY);
        f.setText(ph);
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        f.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (f.getText().equals(ph)) {
                    f.setText("");
                    f.setForeground(DARK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (f.getText().isEmpty()) {
                    f.setText(ph);
                    f.setForeground(Color.GRAY);
                }
            }
        });
        return f;
    }

    static void stylePlaceholder(JPasswordField f, String ph) {
        f.setFont(new Font("Arial", Font.PLAIN, 14));
        f.setBorder(new CompoundBorder(BorderFactory.createLineBorder(GREY),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        f.setEchoChar((char) 0);
        f.setText(ph);
        f.setForeground(Color.GRAY);
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        f.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (new String(f.getPassword()).equals(ph)) {
                    f.setText("");
                    f.setForeground(DARK);
                    f.setEchoChar('●');
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (f.getPassword().length == 0) {
                    f.setEchoChar((char) 0);
                    f.setText(ph);
                    f.setForeground(Color.GRAY);
                }
            }
        });
    }

    static JButton bigButton(String text, Color bg, Color fg) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.BOLD, 14));
        b.setBackground(bg);
        b.setForeground(fg);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        return b;
    }

    static JButton outlineButton(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.BOLD, 14));
        b.setBackground(WHITE);
        b.setForeground(ACCENT);
        b.setFocusPainted(false);
        b.setBorder(new CompoundBorder(BorderFactory.createLineBorder(ACCENT),
                BorderFactory.createEmptyBorder(8, 0, 8, 0)));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        return b;
    }

    static JButton linkButton(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.PLAIN, 13));
        b.setForeground(ACCENT);
        b.setBackground(WHITE);
        b.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setContentAreaFilled(false);
        return b;
    }

    static JLabel msgLabel() {
        JLabel l = new JLabel("", SwingConstants.CENTER);
        l.setFont(new Font("Arial", Font.PLAIN, 12));
        l.setForeground(Color.RED);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        return l;
    }

    static JPanel statBox(String value, String label) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(WHITE);
        JLabel v = new JLabel(value, SwingConstants.CENTER);
        v.setFont(new Font("Arial", Font.BOLD, 18));
        v.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel l = new JLabel(label, SwingConstants.CENTER);
        l.setFont(new Font("Arial", Font.PLAIN, 12));
        l.setForeground(Color.GRAY);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(v);
        p.add(l);
        return p;
    }

    static Component gap(int h) {
        return Box.createRigidArea(new Dimension(0, h));
    }
}
