package algorithm;

import models.post;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class feedranker {

    public List<post> getRankedFeed(List<post> allPosts) {
        PriorityQueue<post> maxHeap = new PriorityQueue<>(
                (a, b) -> b.getLikes() - a.getLikes());
        maxHeap.addAll(allPosts);

        List<post> ranked = new ArrayList<>();
        while (!maxHeap.isEmpty()) {
            ranked.add(maxHeap.poll());
        }
        return ranked;
    }
}