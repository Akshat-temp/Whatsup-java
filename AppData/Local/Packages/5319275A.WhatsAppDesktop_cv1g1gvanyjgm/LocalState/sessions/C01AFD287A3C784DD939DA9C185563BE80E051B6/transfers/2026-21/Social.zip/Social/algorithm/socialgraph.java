package algorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class socialgraph {

    private final Map<String, Set<String>> adjacencyList = new HashMap<>();

    public void addUser(String username) {
        adjacencyList.putIfAbsent(username, new HashSet<>());
    }

    public void removeUser(String username) {
        adjacencyList.remove(username);
        for (Set<String> connections : adjacencyList.values()) {
            connections.remove(username);
        }
    }

    public void follow(String from, String to) {
        adjacencyList.get(from).add(to);
    }

    public void unfollow(String from, String to) {
        adjacencyList.get(from).remove(to);
    }

    public Set<String> getFollowing(String username) {
        return adjacencyList.getOrDefault(username, new HashSet<>());
    }

    public List<String> recommendUsers(String username) {
        Set<String> alreadyFollowing = getFollowing(username);
        Set<String> recommendations = new HashSet<>();

        for (String friend : alreadyFollowing) {
            for (String friendOfFriend : getFollowing(friend)) {
                if (!friendOfFriend.equals(username)
                        && !alreadyFollowing.contains(friendOfFriend)) {
                    recommendations.add(friendOfFriend);
                }
            }
        }
        return new ArrayList<>(recommendations);
    }
}