package models;

public class post {

    private String postId;
    private String authorUsername;
    private String imageUrl;
    private int likes;
    private long timestamp;

    public post(String postId, String authorUsername, String imageUrl) {
        this.postId = postId;
        this.authorUsername = authorUsername;
        this.imageUrl = imageUrl;
        this.likes = 0;
        this.timestamp = System.currentTimeMillis();
    }

    public String getPostId() {
        return postId;
    }

    public String getAuthorUsername() {
        return authorUsername;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public int getLikes() {
        return likes;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void like() {
        likes++;
    }

    public void unlike() {
        if (likes > 0)
            likes--;
    }
}