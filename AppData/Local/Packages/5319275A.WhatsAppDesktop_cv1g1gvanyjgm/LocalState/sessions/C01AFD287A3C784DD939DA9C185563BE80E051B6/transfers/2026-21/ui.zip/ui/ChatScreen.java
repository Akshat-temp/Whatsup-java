package ui;

import database.MessageDAO;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import model.Message;
import model.User;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ChatScreen {

    private User myUser;
    private User contact;
    private VBox messagesBox;
    private ScrollPane scrollPane;
    private Timer timer;
    private int lastMessageCount = 0;

    public ChatScreen(User myUser, User contact) {
        this.myUser = myUser;
        this.contact = contact;
    }

    public void show(Stage stage) {
        stage.setTitle("Whatsup - " + contact.getName());

        Label avatar = new Label(String.valueOf(contact.getName().charAt(0)).toUpperCase());
        avatar.setMinSize(38, 38);
        avatar.setAlignment(Pos.CENTER);
        avatar.setStyle("-fx-background-color: #25D366; -fx-text-fill: white; " +
                "-fx-font-weight: bold; -fx-background-radius: 19;");

        Label nameLabel = new Label(contact.getName());
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        nameLabel.setTextFill(Color.WHITE);

        Label statusLabel = new Label(contact.getPhone());
        statusLabel.setTextFill(Color.web("#25D366"));
        statusLabel.setFont(Font.font("Arial", 11));

        Button backBtn = new Button("\u2190");
        backBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; " +
                "-fx-font-size: 18; -fx-cursor: hand;");
        backBtn.setOnAction(e -> {
            if (timer != null)
                timer.cancel();
            stage.close();
        });

        VBox nameBox = new VBox(2, nameLabel, statusLabel);
        HBox topBar = new HBox(10, backBtn, avatar, nameBox);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(10, 16, 10, 16));
        topBar.setStyle("-fx-background-color: #1F2C34;");

        messagesBox = new VBox(8);
        messagesBox.setPadding(new Insets(12));
        messagesBox.setStyle("-fx-background-color: #0B141A;");

        scrollPane = new ScrollPane(messagesBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: #0B141A; -fx-background: #0B141A;");
        VBox.setVgrow(scrollPane, Priority.ALWAYS);

        loadChatHistory();

        TextField inputField = new TextField();
        inputField.setPromptText("Type a message...");
        inputField.setPrefHeight(42);
        inputField.setStyle("-fx-background-color: #2A3942; -fx-text-fill: white; " +
                "-fx-prompt-text-fill: gray; -fx-background-radius: 20; -fx-padding: 8 12;");

        Button sendBtn = new Button("\u27A4");
        sendBtn.setPrefSize(42, 42);
        sendBtn.setStyle("-fx-background-color: #25D366; -fx-text-fill: white; " +
                "-fx-font-size: 16; -fx-background-radius: 21; -fx-cursor: hand;");

        HBox inputBar = new HBox(8, inputField, sendBtn);
        HBox.setHgrow(inputField, Priority.ALWAYS);
        inputBar.setPadding(new Insets(10, 12, 10, 12));
        inputBar.setAlignment(Pos.CENTER);
        inputBar.setStyle("-fx-background-color: #1F2C34;");

        Runnable sendAction = () -> {
            String text = inputField.getText().trim();
            if (!text.isEmpty()) {
                boolean saved = MessageDAO.saveMessage(myUser.getPhone(), contact.getPhone(), text);
                if (saved) {
                    addMessageBubble(text, getCurrentTime(), true);
                    inputField.clear();
                    scrollToBottom();
                    lastMessageCount++;
                }
            }
        };

        sendBtn.setOnAction(e -> sendAction.run());
        inputField.setOnAction(e -> sendAction.run());

        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                List<Message> msgs = MessageDAO.getMessages(myUser.getPhone(), contact.getPhone());
                if (msgs.size() != lastMessageCount) {
                    Platform.runLater(() -> {
                        lastMessageCount = msgs.size();
                        renderMessages(msgs);
                    });
                }
            }
        }, 2000, 2000);

        VBox root = new VBox(topBar, scrollPane, inputBar);
        root.setStyle("-fx-background-color: #0B141A;");

        stage.setScene(new Scene(root, 420, 620));
        stage.setOnCloseRequest(e -> {
            if (timer != null)
                timer.cancel();
        });
        stage.show();
    }

    private void loadChatHistory() {
        List<Message> messages = MessageDAO.getMessages(myUser.getPhone(), contact.getPhone());
        lastMessageCount = messages.size();
        renderMessages(messages);
    }

    private void renderMessages(List<Message> messages) {
        messagesBox.getChildren().clear();
        for (Message m : messages) {
            boolean isMine = m.getSenderPhone().equals(myUser.getPhone());
            addMessageBubble(m.getContent(), m.getTimestamp(), isMine);
        }
        scrollToBottom();
    }

    private void addMessageBubble(String text, String time, boolean isMine) {
        Label msgLabel = new Label(text);
        msgLabel.setWrapText(true);
        msgLabel.setMaxWidth(260);
        msgLabel.setTextFill(Color.WHITE);
        msgLabel.setFont(Font.font("Arial", 13));

        Label timeLabel = new Label(time);
        timeLabel.setFont(Font.font("Arial", 9));
        timeLabel.setTextFill(Color.LIGHTGRAY);

        VBox bubble = new VBox(4, msgLabel, timeLabel);
        bubble.setPadding(new Insets(8, 12, 8, 12));
        bubble.setMaxWidth(280);

        if (isMine) {
            bubble.setStyle("-fx-background-color: #005C4B; -fx-background-radius: 12 12 0 12;");
            HBox row = new HBox(bubble);
            row.setAlignment(Pos.CENTER_RIGHT);
            row.setPadding(new Insets(2, 8, 2, 50));
            messagesBox.getChildren().add(row);
        } else {
            bubble.setStyle("-fx-background-color: #1F2C34; -fx-background-radius: 12 12 12 0;");
            HBox row = new HBox(bubble);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(2, 50, 2, 8));
            messagesBox.getChildren().add(row);
        }
    }

    private void scrollToBottom() {
        scrollPane.layout();
        scrollPane.setVvalue(1.0);
    }

    private String getCurrentTime() {
        return LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"));
    }
}
