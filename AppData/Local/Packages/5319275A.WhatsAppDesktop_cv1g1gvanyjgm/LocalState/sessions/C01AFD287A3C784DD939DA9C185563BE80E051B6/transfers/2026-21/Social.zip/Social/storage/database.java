package storage;

import java.sql.*;
import java.util.*;
import models.user;
import models.post;

public class database {

    private static final String URL = "jdbc:sqlite:instaclone.db";

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void init() {
        try (Connection conn = connect();
                Statement stmt = conn.createStatement()) {

            stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                    "username TEXT PRIMARY KEY," +
                    "password TEXT" +
                    ")");

            stmt.execute("CREATE TABLE IF NOT EXISTS posts (" +
                    "postId TEXT PRIMARY KEY," +
                    "author TEXT," +
                    "imageUrl TEXT," +
                    "likes INTEGER," +
                    "timestamp LONG" +
                    ")");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveUser(user u) {

        String sql = "INSERT OR IGNORE INTO users(username, password) VALUES(?, ?)";

        try (Connection conn = connect();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());

            int rows = ps.executeUpdate();

            if (rows == 0) {
                System.out.println("User already exists!");
            } else {
                System.out.println("User saved successfully!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static user getUser(String username) {

        String sql = "SELECT * FROM users WHERE username=?";

        try (Connection conn = connect();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new user(
                        rs.getString("username"),
                        rs.getString("password"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static void savePost(post p) {

        String sql = "INSERT INTO posts(postId, author, imageUrl, likes, timestamp) VALUES(?,?,?,?,?)";

        try (Connection conn = connect();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, p.getPostId());
            ps.setString(2, p.getAuthorUsername());
            ps.setString(3, p.getImageUrl());
            ps.setInt(4, p.getLikes());
            ps.setLong(5, p.getTimestamp());

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static List<user> getAllUsers() {
        List<user> list = new ArrayList<>();
        String sql = "SELECT * FROM users";
        try (Connection conn = connect();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next())
                list.add(new user(rs.getString("username"), rs.getString("password")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<post> getAllPosts() {

        List<post> list = new ArrayList<>();

        String sql = "SELECT * FROM posts ORDER BY timestamp DESC";

        try (Connection conn = connect();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {

                post p = new post(
                        rs.getString("postId"),
                        rs.getString("author"),
                        rs.getString("imageUrl"));

                list.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}