package algorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class usertrie {

    private static class TrieNode {
        Map<Character, TrieNode> children = new HashMap<>();
        boolean isEndOfWord = false;
    }

    private final TrieNode root = new TrieNode();

    public void insert(String username) {
        TrieNode current = root;
        for (char c : username.toLowerCase().toCharArray()) {
            current.children.putIfAbsent(c, new TrieNode());
            current = current.children.get(c);
        }
        current.isEndOfWord = true;
    }

    public List<String> searchByPrefix(String prefix) {
        TrieNode current = root;
        for (char c : prefix.toLowerCase().toCharArray()) {
            if (!current.children.containsKey(c)) {
                return new ArrayList<>();
            }
            current = current.children.get(c);
        }
        List<String> results = new ArrayList<>();
        collectAllWords(current, new StringBuilder(prefix.toLowerCase()), results);
        return results.subList(0, Math.min(7, results.size()));
    }

    private void collectAllWords(TrieNode node, StringBuilder word, List<String> results) {
        if (node.isEndOfWord) {
            results.add(word.toString());
        }
        for (Map.Entry<Character, TrieNode> entry : node.children.entrySet()) {
            word.append(entry.getKey());
            collectAllWords(entry.getValue(), word, results);
            word.deleteCharAt(word.length() - 1);
        }
    }

    public void delete(String username) {
        deleteHelper(root, username.toLowerCase(), 0);
    }

    private boolean deleteHelper(TrieNode current, String word, int index) {
        if (index == word.length()) {
            if (!current.isEndOfWord)
                return false;
            current.isEndOfWord = false;
            return current.children.isEmpty();
        }
        char c = word.charAt(index);
        TrieNode next = current.children.get(c);
        if (next == null)
            return false;
        boolean shouldDelete = deleteHelper(next, word, index + 1);
        if (shouldDelete)
            current.children.remove(c);
        return !current.isEndOfWord && current.children.isEmpty();
    }
}