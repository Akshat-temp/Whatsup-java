package model;

public class Message {

    private int    id;
    private String senderPhone;
    private String receiverPhone;
    private int    groupId;
    private String content;
    private String timestamp;
    private boolean isDelivered;

    // Private message constructor
    public Message(String senderPhone, String receiverPhone, String content, String timestamp) {
        this.senderPhone   = senderPhone;
        this.receiverPhone = receiverPhone;
        this.groupId       = 0;
        this.content       = content;
        this.timestamp     = timestamp;
        this.isDelivered   = false;
    }

    // Group message constructor
    public Message(String senderPhone, int groupId, String content, String timestamp) {
        this.senderPhone   = senderPhone;
        this.receiverPhone = null;
        this.groupId       = groupId;
        this.content       = content;
        this.timestamp     = timestamp;
        this.isDelivered   = false;
    }

    public int     getId()            { return id; }
    public String  getSenderPhone()   { return senderPhone; }
    public String  getReceiverPhone() { return receiverPhone; }
    public int     getGroupId()       { return groupId; }
    public String  getContent()       { return content; }
    public String  getTimestamp()     { return timestamp; }
    public boolean isDelivered()      { return isDelivered; }

    public void setId(int id)                  { this.id = id; }
    public void setDelivered(boolean delivered) { this.isDelivered = delivered; }

    public boolean isGroupMessage() { return groupId != 0; }
}
